function palindromeChecker(str) {
    const strReversed = str.split("").reverse().join("");
  
    return strReversed === str ? "es palindromo" : "no es palindromo";
  }
  console.log(palindromeChecker("osi")); // es palindromo
  console.log(palindromeChecker("hola")); // no es palindromo
  console.log(palindromeChecker("omo")); // es palindromo

  function palindromeChecker(str) {
    const newStr = str.replace(/[\W_]/g, "").toLowerCase();
    const strReversed = newStr.split("").reverse().join("");
  
    return newStr === strReversed ? "es palindromo" : "no es palindromo";
  }
  
  console.log(palindromeChecker("Ali tomo tila")); // es palindromo
  console.log(palindromeChecker("Amad a la dama")); // es palindromo
  console.log(palindromeChecker("otra cosa")); // no es palindromo
                



        